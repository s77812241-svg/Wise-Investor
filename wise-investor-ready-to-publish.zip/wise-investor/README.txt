WISE INVESTOR — kit de démarrage bilingue
============================================

FICHIERS
- index.html : page d'accueil avec calculateurs CELI/TFSA, REER/RRSP et hypothèque.
- about.html : page À propos en français et en anglais.
- privacy.html : modèle de politique de confidentialité bilingue.
- contact.html : page de contact à compléter avec une adresse dédiée.
- README.txt : instructions.

PUBLICATION GRATUITE AVEC GITHUB PAGES
1. Créez un compte : https://github.com/
2. Créez un dépôt public appelé wise-investor.
3. Téléversez TOUS les fichiers HTML du dossier dans la racine du dépôt.
4. Dans Settings > Pages, choisissez Deploy from a branch, branche main, dossier /(root), puis Save.
5. Attendez la publication. L'adresse ressemble généralement à https://VOTRE-IDENTIFIANT.github.io/wise-investor/
6. Testez les liens et calculateurs sur téléphone et ordinateur.

AVANT ADSENSE
- Les emplacements publicitaires actuels sont des marqueurs, pas de vraies annonces.
- Ajoutez des articles originaux, complets et vérifiés dans les deux langues. Les aperçus de la page d'accueil ne suffisent pas à eux seuls.
- Remplacez les informations de contact à compléter et adaptez la politique de confidentialité aux services et outils réellement activés.
- Vérifiez les règles applicables au consentement et aux publicités personnalisées selon votre audience.
- Demandez l'examen à https://adsense.google.com/ après avoir publié un site substantiel et fonctionnel.
- L'approbation AdSense n'est jamais garantie. N'insérez pas de code publicitaire avant d'avoir suivi les instructions de Google et obtenu votre identifiant.
- Ne cliquez jamais sur vos propres annonces et ne demandez pas aux autres de le faire.

LIMITES DES CALCULATEURS
- CELI : croissance hypothétique seulement; le calculateur ne détermine pas les droits personnels de cotisation.
- REER : économie d'impôt approximative basée sur le taux marginal entré; ce n'est pas un calcul de déclaration fiscale.
- Hypothèque : estimation utilisant une approximation périodique avec capitalisation semestrielle; le prêteur peut calculer différemment.
- Faites vérifier les résultats et le contenu par une personne qualifiée avant de présenter le site comme une ressource financière complète.

SOURCES
GitHub Pages : https://pages.github.com/
AdSense eligibility: https://support.google.com/adsense/answer/9724
AdSense site preparation: https://support.google.com/adsense/answer/7299563
ARC TFSA contribution room: https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/tax-free-savings-account/contributing/calculate-room.html
